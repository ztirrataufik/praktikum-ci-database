<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bmi extends CI_Controller {
    public function __construct(Type $var = null) {
        parent::__construct();
        $this->load->model('Bmi_pasien');
        $this->load->model('Pasien_model');
    }

    public function index()
	{
        $data['list_bmi_pasien'] = $this->Bmi_pasien->getAll()->result();


		$this->load->view('header');
		$this->load->view('bmi/index', $data);
		$this->load->view('footer');
	}
    
    public function view($id)
    {
        $data['bmi'] = $this->Bmi_pasien->findById($id);
        $data['bmi']->pasien = $this->Pasien_model->findById($data['bmi']->pasien_id);
        $data['view'] = 'bmi/view';

		$this->load->view('header');
		$this->load->view('bmi/view', $data);
		$this->load->view('footer');
    }
}
