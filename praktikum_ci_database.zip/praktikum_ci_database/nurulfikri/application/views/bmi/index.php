<div class="col-md-12">
    <h3>
        Daftar BMI Pasien
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Tanggal Periksa</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Gender</th>
                <th>Berat</th>
                <th>Tinggi</th>
                <th>BMI</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($list_bmi_pasien as $bmi_pasien) { ?>
                <tr>
                    <td><?= $bmi_pasien->id ?></td>
                    <td><?= $bmi_pasien->tanggal ?></td>
                    <td><?= $bmi_pasien->kode ?></td>
                    <td><?= $bmi_pasien->nama ?></td>
                    <td><?= $bmi_pasien->gender ?></td>
                    <td><?= $bmi_pasien->berat ?></td>
                    <td><?= $bmi_pasien->tinggi ?></td>
                    <td><?= $bmi_pasien->bmi ?></td>
                    <td><?= $bmi_pasien->status_bmi ?></td>
                    <td><a href="<?=base_url('index.php/bmi/view/'.$bmi_pasien->id)?>" class="btn btn-primary">View</a></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>